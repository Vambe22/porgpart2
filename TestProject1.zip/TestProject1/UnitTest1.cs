using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PROGpart1.Hubs;
using PROGpart1.Controllers; 
using PROGpart1.Models; 
using PROGpart1.Services; 
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore; 
using Microsoft.AspNetCore.Http;

namespace TestProject1
{
    [TestClass]
    public class ClaimsControllerTests
    {
        private Mock<IClaimService> _mockService;
        private Mock<IHubContext<ClaimHub>> _mockHubContext; // Mock for IHubContext<ClaimHub>
        private ClaimsController _controller;

        [TestInitialize]
        public void Setup()
        {
            // Mock DbContextOptions for ApplicationDbContext
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            // Initialize the mock service and controller before each test
            _mockService = new Mock<IClaimService>();
            _mockHubContext = new Mock<IHubContext<ClaimHub>>(); // Initialize the mock hub context
            _controller = new ClaimsController(new ApplicationDbContext(options), _mockService.Object, _mockHubContext.Object); // Pass the mock to the controller
        }

        [TestMethod]
        public async Task SubmitClaim_ValidClaim_ReturnsRedirectToAction()
        {
            // Arrange
            var claim = new Claim
            {
                HoursWorked = 5,
                HourlyRate = 20,
                Details = "Test claim details"
            };

            var fileMock = new Mock<IFormFile>(); // Create a mock file
            // Setup any file properties you need to simulate here

            // Act
            var result = await _controller.SubmitClaim(claim, fileMock.Object) as RedirectToActionResult; // Await the async method

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Success", result.ActionName);
        }

        [TestMethod]
        public async Task SubmitClaim_InvalidClaim_ReturnsViewWithErrors()
        {
            // Arrange
            _controller.ModelState.AddModelError("HoursWorked", "Required");
            var claim = new Claim(); // Invalid claim

            var fileMock = new Mock<IFormFile>(); // Create a mock file

            // Act
            var result = await _controller.SubmitClaim(claim, fileMock.Object) as ViewResult; // Await the async method

            // Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.ViewData.ModelState.IsValid);
        }

        [TestMethod]
        public async Task ApproveClaim_ExistingClaim_ReturnsRedirectToAction()
        {
            // Arrange
            int claimId = 1; // Assume this claim ID exists
            var claim = new Claim { Id = claimId, Status = "Pending" };
            _mockService.Setup(s => s.GetClaimById(claimId)).ReturnsAsync(claim); // Use ReturnsAsync

            // Act
            var result = await _controller.ApproveClaim(claimId) as RedirectToActionResult; // Await the async method

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("VerifyClaims", result.ActionName);
        }

        [TestMethod]
        public async Task RejectClaim_ExistingClaim_ReturnsRedirectToAction()
        {
            // Arrange
            int claimId = 1; // Assume this claim ID exists
            var claim = new Claim { Id = claimId, Status = "Pending" };
            _mockService.Setup(s => s.GetClaimById(claimId)).ReturnsAsync(claim); // Use ReturnsAsync

            // Act
            var result = await _controller.RejectClaim(claimId) as RedirectToActionResult; // Await the async method

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("VerifyClaims", result.ActionName);
        }
    }
}
