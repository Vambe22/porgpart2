﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROGpart1.Models;
using PROGpart1.Services; // Ensure this matches the actual namespace


namespace PROGpart1.Services
{
    using System.Threading.Tasks;
    using PROGpart1.Models; // Adjust namespace as necessary

    public interface IClaimService
    {
        Task<Claim> GetClaimById(int claimId); // Ensure this is only defined once
        Task<IEnumerable<Claim>> GetAllClaims(); // Example of another method
        Task SubmitClaim(Claim claim); // Example of another method
                                       // Add other method signatures as needed
    }
}