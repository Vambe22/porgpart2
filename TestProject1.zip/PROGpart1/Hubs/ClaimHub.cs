﻿using Microsoft.AspNetCore.SignalR;

namespace PROGpart1.Hubs
{
    public class ClaimHub : Hub
    {
        // This method will be called from the server to notify clients
        public async Task UpdateClaimStatus(int claimId, string status)
        {
            await Clients.All.SendAsync("ReceiveClaimUpdate", claimId, status);
        }
    }
}
