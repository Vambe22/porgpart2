﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using PROGpart1.Hubs;
using PROGpart1.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PROGpart1.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHubContext<ClaimHub> _hubContext; // Add a HubContext for SignalR

        public ClaimsController(ApplicationDbContext context, IHubContext<ClaimHub> hubContext)
        {
            _context = context;
            _hubContext = hubContext; // Initialize the HubContext
        }

        // Submit a new claim with file upload
        [HttpPost]
        public async Task<IActionResult> SubmitClaim(Claim claim, IFormFile file)
        {
            if (ModelState.IsValid)
            {
                // Check if file is uploaded
                if (file != null && file.Length > 0)
                {
                    // Validate file size (limit to 5MB)
                    if (file.Length > 5 * 1024 * 1024)
                    {
                        ModelState.AddModelError("", "File size cannot exceed 5MB.");
                        return View(claim);
                    }

                    // Validate file type
                    var validFileTypes = new[] { ".pdf", ".docx", ".xlsx" };
                    var fileExtension = Path.GetExtension(file.FileName).ToLower();
                    if (!validFileTypes.Contains(fileExtension))
                    {
                        ModelState.AddModelError("", "Invalid file type. Please upload a .pdf, .docx, or .xlsx file.");
                        return View(claim);
                    }

                    // Generate unique file name and save file
                    var uniqueFileName = Path.GetRandomFileName() + fileExtension;
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Save the file path in the claim
                    claim.SupportDocuments = "/uploads/" + uniqueFileName;
                }

                // Set the initial status of the claim
                claim.Status = "Pending";

                // Save the claim to the database
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return View(claim);
        }

        // Approve a claim
        [HttpPost]
        public async Task<IActionResult> ApproveClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Approved";
                await _context.SaveChangesAsync();

                // Notify all clients about the status update
                await _hubContext.Clients.All.SendAsync("ReceiveClaimUpdate", claim.Id, claim.Status);
            }
            return RedirectToAction("VerifyClaims");
        }

        // Reject a claim
        [HttpPost]
        public async Task<IActionResult> RejectClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                await _context.SaveChangesAsync();

                // Notify all clients about the status update
                await _hubContext.Clients.All.SendAsync("ReceiveClaimUpdate", claim.Id, claim.Status);
            }
            return RedirectToAction("VerifyClaims");
        }

        // Action to view pending claims for verification
        public IActionResult VerifyClaims()
        {
            var pendingClaims = _context.Claims.Where(c => c.Status == "Pending").ToList();
            return View(pendingClaims);
        }
    }
}
