﻿using System.ComponentModel.DataAnnotations;

namespace PROGpart1.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public string LecturerName { get; set; }
        public DateTime SubmissionDate { get; set; }
        public string Status { get; set; } // e.g., "Pending", "Approved", "Rejected"
        public string SupportDocuments { get; set; }
        public string Details { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please enter a valid number of hours.")]
        public int HoursWorked { get; set; }

        [Required]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a valid hourly rate.")]
        public decimal HourlyRate { get; set; }
    }

}